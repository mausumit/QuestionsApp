import React from 'react';
import logo from './logo.svg';
import './App.css';
import QuestionsComponent from './Questions/QuestionsComponent';

function App() {
  return (
    <div className="App">
      <QuestionsComponent/>
    </div>
  );
}

export default App;
