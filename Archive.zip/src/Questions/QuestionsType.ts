export type QuestionType ={
    id: number;
    type: string;
    question: string;
    options: Array<string>;
}